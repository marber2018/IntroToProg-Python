'''
Assignment 06
Student: Maria Berschauer
Professor: R. Root
Date: February, 19, 2018
Description: This project is very like the last one,
but this time you will place the code you created for
working with your ToDo.txt file into Functions and a Class.
'''
#Processing Step 1
objFileName = "C:\_PythonClass\Todo.txt"
strData = ""
dicRow = {}
lstTable = []
#Gets the menu choice from a user
@staticmethod
def InputMenuChoice():
# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"
	objFile = open(objFileName, "r")
	for row in objFile:
		lstData = row.strip("\n").split(',')
	dicRow = {"Task": lstData[0], "Priority": lstData[1]}
	lstTable.append(dicRow)
	objFile.close()
# Step 2 - Display a menu of choices to the user

while (True):
	print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)

	strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
	print()  # adding a new line

	# Step 3 -Show the current items in the table
	if (strChoice.strip() == '1'):
		if (lstTable != []):
			print("Here is the current Todo list: \n\n")
			print("Task" + ", " + "Priority")
			for objRow in lstTable:
				print(objRow["Task"] + ", " + objRow["Priority"])
		else:
			print("The Data is Empty")
		input("\nHit enter key to continue")
		continue

	# Step 4 - Add a new item to the list/Table
	elif (strChoice.strip() == '2'):
		#   Assign two user input strings into dictionary variable, dicNewRow

		@staticmethod
		def InputTaskToAdd():


			dicNewRow = {"Task": (input("\nPlease enter a new task: ")),"Priority": (input("Please enter the priority of task '(high/low)' "))}
			lstTable.append(dicNewRow)
		input("\nHit enter key to continue")
		continue

	# Step 5 - Remove a new item to the list/Table
	elif (strChoice == '3'):

		if (lstTable != []):
			print("Here is the current Todo list:\n ")
			for objRow in lstTable:
				print(objRow["Task"] + ", " + objRow["Priority"])

			strRemove = input("\nWhich Task do you want to remove?")
			counter = 0
			for objRow in lstTable:

				if (strRemove == objRow["Task"]):
					lstTable.remove(objRow)

					@staticmethod
					def OutputDeletionStatus(WasItemRemoved):
						print("\nThe Task: " + strRemove + " is removed from Todo list")
					counter += 1

			if (counter == 0): print("The Task: " + strRemove + " is not in the Todo list")
			if (lstTable == []):
				print("The Data is Empty")
		else:
			print("The Data is Empty")
		input("\nHit enter key to continue")
		continue

	# Step 6 - Save tasks to the ToDo.txt file
	elif (strChoice == '4'):
		objFile = open(objFileName, "w")

	@staticmethod
	def InputSaveToFile():
		if (lstTable != []):
			objFile.write("Here is the current Todo list: \n\n")
			objFile.writelines("{:20} {:4}".format("Task", "Priority\n"))
			objFile.write(30 * "-")
			objFile.write("\n")
			for objRow in lstTable:
				objFile.writelines("{:20} {:4}".format(objRow["Task"], objRow["Priority"]))
				objFile.write("\n")
		else:
			print("The Data is Empty")
	break
	objFile.close()
	print("\nThe data is saved in the Todo.txt file\n")
	break

	# Step 7 - Exit the program
		# elif (strChoice == '5'):
	break


